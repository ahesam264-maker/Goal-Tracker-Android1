package com.goaltracker.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/**
 * زمان‌بندی اعلان‌های شخصی کاربر با AlarmManager.
 *
 * - زمان هر اعلان به‌صورت میلی‌ثانیه مطلق (Epoch) از سمت جاوااسکریپت می‌آید
 *   و بر اساس تقویم شمسی + ساعت ایران در index.html محاسبه می‌شود.
 * - آینه‌ای از اعلان‌ها در SharedPreferences نگه داشته می‌شود تا
 *   پس از ری‌استارت گوشی، اعلان‌ها دوباره فعال شوند.
 */
object AlarmScheduler {

    private const val FILE = "masir_alerts"

    fun schedule(ctx: Context, id: String, title: String, body: String, epoch: Long) {
        if (epoch <= System.currentTimeMillis()) return
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val o = JSONObject()
            .put("title", title).put("body", body).put("epoch", epoch)
            .put("updatedAt", System.currentTimeMillis())
        p.edit().putString(id, o.toString()).apply()
        arm(ctx, id, title, body, epoch)
    }

    fun cancel(ctx: Context, id: String) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        p.edit().remove(id).apply()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(ctx, id, title = "", body = ""))
    }

    /** فعال‌سازی مجدد همه اعلان‌های آینده (پس از بوت یا به‌روزرسانی برنامه) */
    fun restoreAll(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        for ((id, value) in p.all) {
            try {
                val o = JSONObject(value.toString())
                val epoch = o.optLong("epoch", 0L)
                if (epoch > now) arm(ctx, id, o.optString("title"), o.optString("body"), epoch)
            } catch (_: Exception) { }
        }
    }

    private fun arm(ctx: Context, id: String, title: String, body: String, epoch: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(ctx, id, title, body)
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epoch, pi)
            } else {
                // در صورت نبود دسترسی «اعلان دقیق»، زمان‌بندی تقریبی انجام می‌شود
                am.set(AlarmManager.RTC_WAKEUP, epoch, pi)
            }
        } catch (e: SecurityException) {
            try { am.set(AlarmManager.RTC_WAKEUP, epoch, pi) } catch (_: Exception) { }
        }
    }

    private fun pendingIntent(ctx: Context, id: String, title: String, body: String): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra("id", id); putExtra("title", title); putExtra("body", body)
        }
        return PendingIntent.getBroadcast(
            ctx, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

/** نمایش اعلان در زمان تعیین‌شده */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: "alert"
        val title = intent.getStringExtra("title") ?: "یادآوری مسیر"
        val body = intent.getStringExtra("body") ?: ""
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("masir_alerts", "اعلان‌های زمان‌بندی‌شده", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(context, "masir_alerts")
                .setSmallIcon(R.drawable.ic_stat_timer)
                .setContentTitle(title)
                .setContentText(if (body.isBlank()) "یادآوری برنامه مسیر" else body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(if (body.isBlank()) title else "$title\n$body"))
                .setAutoCancel(true)
                .setContentIntent(open)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
            nm.notify(id.hashCode(), n)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

/** بازیابی اعلان‌ها پس از ری‌استارت گوشی یا به‌روزرسانی برنامه */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            try { AlarmScheduler.restoreAll(context) } catch (_: Exception) { }
        }
    }
}
