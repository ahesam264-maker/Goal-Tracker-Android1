package com.goaltracker.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.lang.ref.WeakReference

/**
 * نقطه ورود اپلیکیشن: یک WebView که همان index.html پروژه وب را
 * از file:///android_asset/index.html بارگذاری می‌کند.
 * تمام منطق برنامه (اهداف، مسیر، تایمرها، گزارش‌ها) در همان HTML/JS قبلی است.
 */
class MainActivity : AppCompatActivity() {

    lateinit var webView: WebView
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true          // localStorage برای ذخیره اهداف
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                // فقط لینک‌های داخلی باز شوند؛ بقیه در مرورگر سیستم
                return !(url.startsWith("file://") || url.startsWith("about:"))
            }
        }

        webView.addJavascriptInterface(MasirNative(this), "MasirNative")
        TimerService.webViewRef = WeakReference(webView)

        // مجوز نمایش اعلان (اندروید 13 به بعد)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }

        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        // همگام‌سازی وضعیت تایمرها با سرویس پس‌زمینه هنگام بازگشت به برنامه
        try {
            webView.evaluateJavascript("window.__nativeResume && window.__nativeResume();", null)
        } catch (_: Exception) {
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object {
        private const val REQ_NOTIF = 101
    }
}

/**
 * پل بین جاوااسکریپت و امکانات بومی اندروید.
 * نام شیء MasirNative دقیقاً همان چیزی است که در index.html بررسی می‌شود.
 */
class MasirNative(private val activity: MainActivity) {

    private val prefs: android.content.SharedPreferences
        get() = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /* ---------- تایمر ---------- */

    @JavascriptInterface
    fun startTimer(id: String, name: String, endAt: Long) {
        TimerService.start(activity, id, name, endAt)
    }

    @JavascriptInterface
    fun pauseTimer(id: String, remaining: Long) {
        TimerService.pause(activity, id, remaining)
    }

    @JavascriptInterface
    fun stopTimer(id: String) {
        TimerService.stop(activity, id)
    }

    /** وضعیت همه تایمرها به‌صورت JSON برای همگام‌سازی با رابط کاربری */
    @JavascriptInterface
    fun getTimerStates(): String {
        return TimerService.statesJson(activity)
    }

    /* ---------- اعلان‌های زمان‌بندی‌شده ---------- */

    @JavascriptInterface
    fun scheduleAlert(id: String, title: String, body: String, epoch: Long) {
        AlarmScheduler.schedule(activity, id, title, body, epoch)
    }

    @JavascriptInterface
    fun cancelAlert(id: String) {
        AlarmScheduler.cancel(activity, id)
    }

    @JavascriptInterface
    fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102
            )
        }
    }

    @JavascriptInterface
    fun hasExactAlarm(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) {
            val am = activity.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            am.canScheduleExactAlarms()
        } else true
    }

    @JavascriptInterface
    fun requestExactAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${activity.packageName}")
            }
            try { activity.startActivity(intent) } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun versionName(): String {
        return try { activity.packageManager.getPackageInfo(activity.packageName, 0).versionName ?: "1.0.0" }
        catch (_: Exception) { "1.0.0" }
    }

    @JavascriptInterface
    fun storageInfo(): String {
        // فقط برای نمایش وضعیت؛ اطلاعات اصلی در WebView localStorage است
        return try { prefs.all.size.toString() } catch (_: Exception) { "0" }
    }

    companion object {
        const val PREFS_NAME = "masir_native"
    }
}
