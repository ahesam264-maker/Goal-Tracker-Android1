package com.goaltracker.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import java.lang.ref.WeakReference
import org.json.JSONObject
import java.util.Locale

/**
 * سرویس Foreground برای اجرای تایمرها در پس‌زمینه اندروید.
 *
 * محاسبه زمان بر اساس Timestamp (میلی‌ثانیه مطلق پایان) انجام می‌شود، نه شمارنده داخلی،
 * بنابراین تأخیر خواب سیستم روی دقت تأثیری ندارد و پس از بازگشت، زمان درست محاسبه می‌شود.
 *
 * دکمه‌های اعلان: Pause / Play / X
 */
class TimerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val running = LinkedHashMap<String, Long>()   // id -> endAt (epoch ms)
    private val paused = HashMap<String, Long>()          // id -> باقی‌مانده (ms)
    private val names = HashMap<String, String>()         // id -> نام/نوع فعالیت
    private var notifIdCounter = 1000

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val ended = running.filterValues { it <= now }.keys.toList()
            ended.forEach { id ->
                running.remove(id)
                val remaining = paused.remove(id)
                Persist.remove(this@TimerService, id)
                postFinishedNotification(id, names[id] ?: "تایمر")
                notifyWeb("window.MasirNativeAction && MasirNativeAction('$id','ended',0)")
            }
            updateNotification()
            if (running.isEmpty() && paused.isEmpty()) {
                stopSelf()
                return
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id") ?: ""
        when (intent?.action) {
            ACTION_START -> {
                val endAt = intent.getLongExtra("endAt", 0L)
                val name = intent.getStringExtra("name") ?: "تایمر"
                if (endAt > System.currentTimeMillis()) {
                    running[id] = endAt
                    names[id] = name
                    Persist.put(this, id, name, true, endAt, 0)
                }
            }
            ACTION_PAUSE -> {
                val remaining = intent.getLongExtra("remaining", 0L)
                if (running.remove(id) != null && remaining > 0) {
                    paused[id] = remaining
                    Persist.put(this, id, names[id] ?: "تایمر", false, 0, remaining)
                }
            }
            ACTION_RESUME -> {
                val remaining = intent.getLongExtra("remaining", 0L)
                if (paused.remove(id) != null && remaining > 0) {
                    val endAt = System.currentTimeMillis() + remaining
                    running[id] = endAt
                    Persist.put(this, id, names[id] ?: "تایمر", true, endAt, 0)
                }
            }
            ACTION_STOP -> {
                running.remove(id); paused.remove(id); names.remove(id)
                Persist.remove(this, id)
            }
        }

        // شروع سرویس پس‌زمینه با اعلان دائمی
        startForeground(NOTIF_ID, buildNotification())

        handler.removeCallbacks(ticker)
        if (running.isNotEmpty() || paused.isNotEmpty()) handler.postDelayed(ticker, 200)
        else stopSelf()

        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        // اگر سرویس توسط سیستم کشته شد، وضعیت در SharedPreferences باقی می‌ماند
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /* ---------- اعلان دائمی ---------- */

    private fun buildNotification(): Notification {
        val firstId = running.keys.firstOrNull() ?: paused.keys.firstOrNull() ?: "تایمر"
        val name = names[firstId] ?: Persist.nameOf(this, firstId) ?: "تایمر"
        val remaining = remainingOf(firstId)
        val isRunning = running.containsKey(firstId)

        val timeText = formatMs(remaining)
        val content = if (isRunning) {
            String.format(Locale.US, "باقی‌مانده: %s", timeText)
        } else {
            String.format(Locale.US, "متوقف — باقی‌مانده: %s", timeText)
        }

        val base = Intent(this, MainActivity::class.java)
        val contentPi = PendingIntent.getActivity(this, 0, base, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // دکمه Pause / Play
        val toggleAction = if (isRunning) ACTION_PAUSE else ACTION_RESUME
        val toggleIcon = if (isRunning) R.drawable.ic_action_pause else R.drawable.ic_action_play
        val togglePi = PendingIntent.getService(
            this, (firstId + toggleAction).hashCode(),
            Intent(this, TimerService::class.java).apply {
                action = toggleAction; putExtra("id", firstId); putExtra("remaining", remaining)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // دکمه X (توقف کامل + پایان سرویس + حذف اعلان)
        val stopPi = PendingIntent.getService(
            this, (firstId + "stop").hashCode(),
            Intent(this, TimerService::class.java).apply { action = ACTION_STOP; putExtra("id", firstId) },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (running.size + paused.size > 1) "چند تایمر فعال" else name

        return NotificationCompat.Builder(this, CHANNEL_TIMER)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(title)
            .setContentText(content)
            .setSubText("مسیر — مدیریت اهداف")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(contentPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(R.drawable.ic_action_pause, if (isRunning) "Pause" else "Play", togglePi)
            .addAction(R.drawable.ic_action_close, "X", stopPi)
            .build()
    }

    private fun updateNotification() {
        if (running.isEmpty() && paused.isEmpty()) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.notify(NOTIF_ID, buildNotification()) } catch (_: Exception) { }
    }

    private fun postFinishedNotification(id: String, name: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val contentPi = PendingIntent.getActivity(
            this, id.hashCode(), Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(name)
            .setContentText("زمان تمام شد")
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        try { nm.notify((id + "ended").hashCode(), n) } catch (_: Exception) { }
    }

    private fun remainingOf(id: String): Long {
        running[id]?.let { return (it - System.currentTimeMillis()).coerceAtLeast(0) }
        return paused[id] ?: 0L
    }

    private fun formatMs(ms: Long): String {
        val totalSec = (ms / 1000).toInt()
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun notifyWeb(js: String) {
        try { webViewRef?.get()?.evaluateJavascript(js, null) } catch (_: Exception) { }
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_TIMER, "تایمر", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ALERTS, "اعلان‌ها", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    companion object {
        const val ACTION_START = "com.goaltracker.timer.START"
        const val ACTION_PAUSE = "com.goaltracker.timer.PAUSE"
        const val ACTION_RESUME = "com.goaltracker.timer.RESUME"
        const val ACTION_STOP = "com.goaltracker.timer.STOP"
        const val CHANNEL_TIMER = "masir_timer"
        const val CHANNEL_ALERTS = "masir_alerts"
        const val NOTIF_ID = 77001

        var webViewRef: WeakReference<WebView>? = null

        fun start(ctx: Context, id: String, name: String, endAt: Long) {
            val i = Intent(ctx, TimerService::class.java).apply {
                action = ACTION_START; putExtra("id", id); putExtra("name", name); putExtra("endAt", endAt)
            }
            startSvc(ctx, i)
        }

        fun pause(ctx: Context, id: String, remaining: Long) {
            val i = Intent(ctx, TimerService::class.java).apply {
                action = ACTION_PAUSE; putExtra("id", id); putExtra("remaining", remaining)
            }
            startSvc(ctx, i)
        }

        fun stop(ctx: Context, id: String) {
            val i = Intent(ctx, TimerService::class.java).apply {
                action = ACTION_STOP; putExtra("id", id)
            }
            startSvc(ctx, i)
        }

        private fun startSvc(ctx: Context, i: Intent) {
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        /** وضعیت آینه‌شده تایمرها برای همگام‌سازی با رابط وب */
        fun statesJson(ctx: Context): String {
            val all = Persist.all(ctx)
            val out = JSONObject()
            val now = System.currentTimeMillis()
            for (id in all.keys()) {
                val o = all.getJSONObject(id)
                val runningFlag = o.optBoolean("running", false)
                val endAt = o.optLong("endAt", 0L)
                val left = o.optLong("left", 0L)
                val rec = JSONObject()
                if (runningFlag && endAt > now) {
                    rec.put("running", true); rec.put("endAt", endAt); rec.put("left", endAt - now)
                } else if (runningFlag && endAt <= now) {
                    rec.put("running", false); rec.put("ended", true); rec.put("left", 0)
                } else {
                    rec.put("running", false); rec.put("left", left)
                }
                out.put(id, rec)
            }
            return out.toString()
        }
    }

    /** آینه وضعیت تایمرها در SharedPreferences تا پس از کشته‌شدن برنامه هم قابل بازیابی باشد */
    object Persist {
        private const val FILE = "masir_timers"

        fun put(ctx: Context, id: String, name: String, running: Boolean, endAt: Long, left: Long) {
            val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val o = JSONObject()
                .put("name", name).put("running", running).put("endAt", endAt).put("left", left)
                .put("updatedAt", System.currentTimeMillis())
            p.edit().putString(id, o.toString()).apply()
        }

        fun remove(ctx: Context, id: String) {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(id).apply()
        }

        fun all(ctx: Context): JSONObject {
            val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val out = JSONObject()
            for ((k, v) in p.all) {
                try { out.put(k, JSONObject(v.toString())) } catch (_: Exception) { }
            }
            return out
        }

        fun nameOf(ctx: Context, id: String): String? {
            return try {
                val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
                p.getString(id, null)?.let { JSONObject(it).optString("name") }
            } catch (_: Exception) { null }
        }
    }
}
